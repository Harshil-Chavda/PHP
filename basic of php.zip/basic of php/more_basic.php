<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>more_basic of php</title>
</head>
<style>
    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    .container{
        max-width: 80%;
        background-color: gray;
        margin: auto;
        padding: 23px;
    }
</style>
<body>


    <div class="container">
 
    thhi is container.

    
        <?php
            $age = 23;
            if ($age>18) {
                echo "you can go to drive a car"
            }
            elseif($age == 17){
                echo "after the one year you can  go to drive a car";
            }
            else
            {
                echo  "you can not go to drive a car";

            }



            $languages = array("PYTHON", "C++", "C", "JS", "JAVA")
            echo "this is array : $languages[4]";
        ?>
    </div>
    
</body>
</html>